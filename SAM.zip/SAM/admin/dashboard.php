<?php

    include("header.php");
    $Boys= 48;
    $Girls = 52;
?>
<div class="container" >
    <div class="col-md-4" style="margin-top:20px;">
      <div class="card">
        <div class="card-header ">
        <h3>Student Count</h3>
        </div>
        <div class="card-body">
        <div class="card-body" id="piechart"></div>
        </div>
      </div>
    </div>

</div>
</body>
</html>

<script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>

<script type="text/javascript">
// Load google charts
google.charts.load('current', {'packages':['corechart']});
google.charts.setOnLoadCallback(drawChart);

// Draw the chart and set the chart values
function drawChart() {
    
  var data = google.visualization.arrayToDataTable([
  ['Task', 'Hours per Day'],
  ['Boys', <?php echo $Boys; ?>],
  ['Girls', <?php echo $Girls; ?>],
]);

  // Optional; add a title and set the width and height of the chart
  //var options = {};
//  var options = {'width':800, 'height':700};
var options = {
    chartArea: {
      // leave room for y-axis labels
      left: 40,
      width: '100%'
    },
    legend: {
      position: 'top'
    },
    width: '100%'
  };

  // Display the chart inside the <div> element with id="piechart"
  var chart = new google.visualization.PieChart(document.getElementById('piechart'));
  chart.draw(data, options);
}
</script>

