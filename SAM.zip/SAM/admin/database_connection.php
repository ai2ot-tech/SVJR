<?php

//database_connection.php
$connect = new PDO("mysql:host=localhost;dbname=attendance","root","");
//$connect = new PDO("mysql:host=sql6.freemysqlhosting.net;dbname=sql6409406","sql6409406","siNVAlFLsU");

//$base_url = "http://localhost/tutorial/SAM/";
$base_url = "../";

function get_total_records($connect, $table_name)
{
	$query = "SELECT * FROM $table_name";
	$statement = $connect->prepare($query);
	$statement->execute();
	return $statement->rowCount();
}
function get_total_records_condition($connect, $table_name, $condition)
{
	$query = "SELECT * FROM $table_name $condition";
	$statement = $connect->prepare($query);
	$statement->execute();
	return $statement->rowCount();
}
function get_teacher_grade_id($connect, $teacher_id){
	$query = "SELECT teacher_grade_id from tbl_teacher where teacher_id = '$teacher_id' LIMIT 1" ;
	$statement = $connect->prepare($query);
	$statement->execute();
	$result = $statement->fetchAll();
	foreach($result as $row)
	{		
	return $row["teacher_grade_id"];
	}
}
function load_grade_list($connect)
{
	$query = "
	SELECT * FROM tbl_grade ORDER BY grade_name ASC
	";
	$statement = $connect->prepare($query);
	$statement->execute();
	$result = $statement->fetchAll();
	$output = '';
	foreach($result as $row)
	{
		$output .= '<option value="'.$row["grade_id"].'">'.$row["grade_name"].'</option>';
	}
	return $output;
}

function load_grade_list_fee($connect)
{
	$query = "
	SELECT * FROM tbl_grade
	where tbl_grade.grade_id NOT IN (SELECT fee_grade_id FROM tbl_grade_fee_structure)
	ORDER BY grade_name ASC
	";
	$statement = $connect->prepare($query);
	$statement->execute();
	$result = $statement->fetchAll();
	$output = '';
	foreach($result as $row)
	{
		$output .= '<option value="'.$row["grade_id"].'">'.$row["grade_name"].'</option>';
	}
	return $output;
}


function get_attendance_percentage($connect, $student_id)
{
	$query = "
	SELECT 
		ROUND((SELECT COUNT(*) FROM tbl_attendance 
		WHERE attendance_status = 'Present' 
		AND student_id = '".$student_id."') 
	* 100 / COUNT(*)) AS percentage FROM tbl_attendance 
	WHERE student_id = '".$student_id."'
	";

	$statement = $connect->prepare($query);
	$statement->execute();
	$result = $statement->fetchAll();
	foreach($result as $row)
	{
		if($row["percentage"] > 0)
		{
			return $row["percentage"] . '%';
		}
		else
		{
			return 'NA';
		}
	}
}

function Get_student_roll_number($connect, $student_id, $grade_id){
	$query = "SELECT * FROM tbl_student where student_id = '$student_id' and student_grade_id = '$grade_id'";
	$statement = $connect->prepare($query);
	$statement->execute();
	return $statement->rowCount();
}

function Get_student_name($connect, $student_id)
{
	$query = "
	SELECT student_name FROM tbl_student 
	WHERE student_id = '".$student_id."'
	";

	$statement = $connect->prepare($query);

	$statement->execute();

	$result = $statement->fetchAll();

	foreach($result as $row)
	{
		return $row["student_name"];
	}
}
function Get_student_details($connect, $student_id)
{
	$output[]='';
	$query = "
	SELECT * FROM tbl_student 
	WHERE student_id = '".$student_id."' LIMIT 1
	";
	$statement = $connect->prepare($query);
	$statement->execute();
	$result = $statement->fetchAll();
	foreach($result as $row)
	{
		$output["student_name"]= $row["student_name"];
		$output["student_father_name"]= $row["student_father_name"];
		$output["student_phone_number"]= $row["student_phone_number"];
		$output["student_grade_id"]= $row["student_grade_id"];
		$output["student_aadhar_number"]= $row["student_aadhar_number"];
		$output["student_address"]= $row["student_address"];
		$output["student_gender"]= $row["student_gender"];
	}
	return $output;
}
function Get_student_fee_details($connect, $student_id)
{
	$output[]='';
	$query = "
	SELECT tbl_grade.grade_name,tbl_student.student_id,student_name,student_phone_number,tbl_grade_fee_structure.fee_grade_id,
        (school_fee+hostel_fee+tution_fee+misc_fee) as total_fee,
        (select sum(paid_amount) from tbl_fee_transactions where student_id = tbl_student.student_id) as paid_fee,
        ((school_fee+hostel_fee+tution_fee+misc_fee) - (select sum(paid_amount) from tbl_fee_transactions where student_id = tbl_student.student_id)) as balance_fee
        FROM tbl_grade_fee_structure 
        join tbl_grade
        ON tbl_grade_fee_structure.fee_grade_id = tbl_grade.grade_id
        JOIN tbl_student on tbl_grade_fee_structure.fee_grade_id = tbl_student.student_grade_id
		WHERE tbl_student.student_id = '".$student_id."' LIMIT 1
	";
	$statement = $connect->prepare($query);
	$statement->execute();
	$result = $statement->fetchAll();
	foreach($result as $row)
	{
		$output["total_fee"]= $row["total_fee"];
		$output["paid_fee"]= $row["paid_fee"];
		$output["balance_fee"]= $row["balance_fee"];
	}
	return $output;
}

function Get_student_grade_name($connect, $student_id)
{
	$query = "
	SELECT tbl_grade.grade_name FROM tbl_student 
	INNER JOIN tbl_grade 
	ON tbl_grade.grade_id = tbl_student.student_grade_id 
	WHERE tbl_student.student_id = '".$student_id."'
	";
	$statement = $connect->prepare($query);
	$statement->execute();
	$result = $statement->fetchAll();
	foreach($result as $row)
	{
		return $row['grade_name'];
	}
}

function Get_student_teacher_name($connect, $student_id)
{
	$query = "
	SELECT tbl_teacher.teacher_name 
	FROM tbl_student 
	INNER JOIN tbl_grade 
	ON tbl_grade.grade_id = tbl_student.student_grade_id 
	INNER JOIN tbl_teacher 
	ON tbl_teacher.teacher_grade_id = tbl_grade.grade_id 
	WHERE tbl_student.student_id = '".$student_id."'
	";
	$statement = $connect->prepare($query);
	$statement->execute();
	$result = $statement->fetchAll();
	foreach($result as $row)
	{
		return $row["teacher_name"];
	}
}

function Get_grade_name($connect, $grade_id)
{
	$query = "
	SELECT grade_name FROM tbl_grade 
	WHERE grade_id = '".$grade_id."'
	";
	$statement = $connect->prepare($query);
	$statement->execute();
	$result = $statement->fetchAll();
	foreach($result as $row)
	{
		return $row["grade_name"];
	}
}
?>