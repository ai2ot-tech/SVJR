<?php

//student_action.php

include('database_connection.php');

session_start();

if(isset($_POST["action"]))
{
    if($_POST["action"] == "edit_grade_fetch")
	{
		$query = "
		SELECT * FROM tbl_grade WHERE grade_id = '".$_POST["grade_id"]."'
		";
		$statement = $connect->prepare($query);
		if($statement->execute())
		{
			$result = $statement->fetchAll();
			foreach($result as $row)
			{
				$output["grade_name"] = $row["grade_name"];
				$output["grade_id"] = $row["grade_id"];
			}
		}
		$data=$output;
		echo json_encode($data);
	}

	if($_POST["action"] == "edit_fetch")
	{
		$query = "
		SELECT * FROM tbl_subject 
		WHERE subject_id = '".$_POST["subject_id"]."'
		";
		$statement = $connect->prepare($query);
		if($statement->execute())
		{
			$result = $statement->fetchAll();
			foreach($result as $row)
			{
				$output["subject_id"] = $row["subject_id"];
				$output["subject_name"] = $row["subject_name"];
				$output["subject_code"] = $row["subject_code"];
                $output["subject_desc"] = $row["subject_desc"];
                $output["subject_grade_id"] = $row["subject_grade_id"];
			}
		}
		$data=$output;
		echo json_encode($data);
	}
}
?>