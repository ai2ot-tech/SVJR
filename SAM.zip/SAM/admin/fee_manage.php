<?php

//student.php

include('header.php');

?>

<div class="container" style="margin-top:30px">
  <div class="card">
  	<div class="card-header">
      <div class="row">
        <div class="col-md-9">Fee Management</div>
        <div class="col-md-3" align="right">
        	<button hidden type="button" id="add_button" class="btn btn-info btn-sm">Add</button>
        </div>
      </div>
    </div>
  	<div class="card-body">
  		<div class="table-responsive">
        	<span id="message_operation"></span>
        	<table class="table table-striped table-bordered" id="student_table">
  				<thead class="thead-dark">
  					<tr>            
  						<th>Student Name</th>
              <th>Phone number</th>
              <th>Grade</th>
              <th>Total</th>
  						<th>Paid</th>
              <th>Balance</th>
              <th>Action</th>
  					</tr>
  				</thead>
  				<tbody>

  				</tbody>
  			</table>
  			
  		</div>
  	</div>
  </div>
</div>

</body>
</html>

<script type="text/javascript" src="../js/bootstrap-datepicker.js"></script>
<link rel="stylesheet" href="../css/datepicker.css" />

<style>
    .datepicker {
      z-index: 1600 !important; /* has to be larger than 1050 */
    }
</style>

<div class="modal" id="formModal">
  <div class="modal-dialog">
  	<form method="post" id="student_form">
      <div class="modal-content">

        <!-- Modal Header -->
        <div class="modal-header">
          <h4 class="modal-title" id="modal_title"></h4>
          <button type="button" class="close" data-dismiss="modal">&times;</button>
        </div>

        <!-- Modal body -->
        <div class="modal-body">
        <div class="form-group">
            <div class="row">
              <label hidden class="col-md-4 text-left"> Student id <span class="text-danger">*</span></label>
              <div class="col-md-8">
                <input hidden type="text" name="fee_student_id" id="fee_student_id" class="form-control" />
                <span id="error_fee_student_id" class="text-danger"></span>
              </div>
              
            </div>
          </div>
          <div class="form-group">
            <div class="row">
              <label class="col-md-4 text-left"> Student Name <span class="text-danger">*</span></label>
              <div class="col-md-8">
                <input type="text" name="student_name" id="student_name" class="form-control" />
                <span id="error_student_name" class="text-danger"></span>
              </div>
              
            </div>
          </div>
          <div class="form-group">
            <div class="row">
              <label class="col-md-4 text-left">Grade <span class="text-danger">*</span></label>
              <div class="col-md-8">
                <select name="student_grade_id" id="student_grade_id" class="form-control">
                  <option value="">Select Grade</option>
                  <?php
                  echo load_grade_list($connect);
                  ?>
              </select>
              <span id="error_student_grade_id" class="text-danger"></span>
              </div>
            </div>
          </div>
          <div class="form-group">
            <div class="row">
            <label class="col-md-4 text-left">Roll No. <span class="text-danger">*</span></label>
              <div class="col-md-8">
                <input type="text" name="student_roll_number" id="student_roll_number" class="form-control" />
                <span id="error_student_roll_number" class="text-danger"></span>
              </div>
            </div>
          </div>
          <div class="form-group">
            <div class="row">
              <label class="col-md-4 text-left">Phone Number <span class="text-danger">*</span></label>
              <div class="col-md-8">
                <input type="number" name="student_phone_number" id="student_phone_number" class="form-control" />
                <span id="error_student_phone_number" class="text-danger"></span>
              </div>
            </div>
          </div>
          <div class="form-group">
            <div class="row">
              <label class="col-md-4 text-left">Payment Amount <span class="text-danger">*</span></label>
              <div class="col-md-8">
                <input type="number" name="paid_amount" id="paid_amount" class="form-control" />
                <span id="error_paid_amount" class="text-danger"></span>
              </div>
            </div>
          </div>
          <div class="form-group">
            <div class="row">
              <label class="col-md-4 text-left">Payment Remarks <span class="text-danger">*</span></label>
              <div class="col-md-8">
                <input type="text" name="comments" id="comments" class="form-control" />
                <span id="error_comments" class="text-danger"></span>
              </div>
            </div>
          </div>
          
          <div class="form-group">
            <div class="row">
              
            </div>
          </div>
        </div>

        <!-- Modal footer -->
        <div class="modal-footer">
        	<input type="hidden" name="student_id" id="student_id" />
        	<input type="hidden" name="action" id="action" value="Add" />
        	<input type="submit" name="button_action" id="button_action" class="btn btn-success btn-sm" value="Make Payment" />
          	<button type="button" class="btn btn-danger btn-sm" data-dismiss="modal">Close</button>
        </div>

      </div>
  </form>
  </div>
</div>

<div class="modal" id="viewModal">
  <div class="modal-dialog modal-lg">
    <div class="modal-content">

      <!-- Modal Header -->
      <div class="modal-header">
        <h4 class="modal-title">Student Payment Details</h4>
        <button type="button" class="close" data-dismiss="modal">&times;</button>
      </div>

      <!-- Modal body -->
      <div class="modal-body" id="student_details">

      </div>

      <!-- Modal footer -->
      <div class="modal-footer">
        <button type="button" name="ok_button" id="ok_button" class="btn btn-primary btn-sm">Print</button>
        <button type="button" class="btn btn-danger btn-sm" data-dismiss="modal">Close</button>
      </div>

    </div>
  </div>
</div>

<div class="modal" id="deleteModal">
  <div class="modal-dialog">
    <div class="modal-content">

      <!-- Modal Header -->
      <div class="modal-header">
        <h4 class="modal-title">Print Confirmation</h4>
        <button type="button" class="close" data-dismiss="modal">&times;</button>
      </div>

      <!-- Modal body -->
      <div class="modal-body">
        <h3 align="center">Comming Soon</h3>
      </div>

      <!-- Modal footer -->
      <div class="modal-footer">
        <button type="button" name="ok_button" id="ok_button" class="btn btn-primary btn-sm">OK</button>
        <button type="button" class="btn btn-danger btn-sm" data-dismiss="modal">Close</button>
      </div>

    </div>
  </div>
</div>


<script>
$(document).ready(function(){
	
	var dataTable = $('#student_table').DataTable({
		"processing":true,
		"serverSide":true,
		"order":[],
    'columnDefs': [ {
        'targets': [0,3], // column index (start from 0)
        'orderable': false, // set orderable false for selected columns
     }],
		"ajax":{
			url:"fee_manage_action.php",
			method:"POST",
			data:{action:'fetch'},
		}
	});

	function clear_field()
	{
		$('#student_form')[0].reset();
		$('#error_paid_amount').text('');
		$('#error_comments').text('');
	}
  var student_id = '';

	$('#student_form').on('submit', function(event){
		event.preventDefault();
		$.ajax({
			url:"fee_manage_action.php",
			method:"POST",
			data:$(this).serialize(),
			dataType:"json",
			beforeSend:function(){
				$('#button_action').val('Validate...');
				$('#button_action').attr('disabled', 'disabled');
			},
			success:function(data)
			{
				$('#button_action').attr('disabled', false);
				$('#button_action').val($('#action').val());
				if(data.success)
				{
					$('#message_operation').html('<div class="alert alert-success">'+data.success+'</div>');
					clear_field();
					$('#formModal').modal('hide');
					dataTable.ajax.reload();
				}
				if(data.error)
				{
					if(data.error_paid_amount != '')
					{
						$('#error_paid_amount').text(data.error_paid_amount);
					}
					else
					{
						$('#error_paid_amount').text('');
					}
					if(data.error_comments != '')
					{
						$('#error_comments').text(data.error_comments);
					}
					else
					{
						$('#error_comments').text('');
					}
				}
			}
		})
	});

  

  $(document).on('click', '.edit_student', function(){
    student_id = $(this).attr('id');
    clear_field();
    $.ajax({
      url:"fee_manage_action.php",
      method:"POST",
      data:{action:'edit_fetch', student_id:student_id},
      dataType:"json",
      success:function(data)
      {
        $('#fee_student_id').val(data.student_id);
        $('#student_name').val(data.student_name).prop('disabled',true);
        $('#student_roll_number').val(data.student_roll_number).prop('disabled',true);
        $('#student_phone_number').val(data.student_phone_number).prop('disabled',true);
        $('#student_grade_id').val(data.student_grade_id).prop('disabled',true);
        $('#modal_title').text('Take Fee Payment');
        $('#button_action').val('Submit Payment');
        $('#action').val('Edit');
        $('#formModal').modal('show');
      }
    })
  });

  student_id = '';
  $(document).on('click', '.view_student', function(){
    student_id = $(this).attr('id');
    $.ajax({
      url:"fee_manage_action.php",
      method:"POST",
      data:{action:'single_fetch', student_id:student_id},
      success:function(data)
      {
        $('#viewModal').modal('show');
        $('#student_details').html(data);
      }
    });
  });

  $(document).on('click', '.delete_student', function(){
    student_id = $(this).attr('id');
    $('#deleteModal').modal('show');
  });

  $('#ok_button').click(function(){
    $.ajax({
      url:"fee_manage_action.php",
      method:"POST",
      data:{student_id:student_id, action:"delete"},
      success:function(data)
      {
        $('#message_operation').html('<div class="alert alert-success">'+data+'</div>');
        $('#deleteModal').modal('hide');
        dataTable.ajax.reload();
      }
    })
  });

});
</script>