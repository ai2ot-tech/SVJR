<?php

//student_action.php

include('database_connection.php');

session_start();

if(isset($_POST["action"]))
{
	if($_POST["action"] == "fetch")
	{
		$query = "
		SELECT tbl_grade.grade_name,tbl_student.student_id,student_name,student_phone_number,tbl_grade_fee_structure.fee_grade_id,
        (school_fee+hostel_fee+tution_fee+misc_fee) as total_fee,
        (select sum(paid_amount) from tbl_fee_transactions where student_id = tbl_student.student_id) as paid_fee,
        ((school_fee+hostel_fee+tution_fee+misc_fee) - (select sum(paid_amount) from tbl_fee_transactions where student_id = tbl_student.student_id)) as balance_fee
        FROM tbl_grade_fee_structure 
        join tbl_grade
        ON tbl_grade_fee_structure.fee_grade_id = tbl_grade.grade_id
        JOIN tbl_student on tbl_grade_fee_structure.fee_grade_id = tbl_student.student_grade_id
		";

		if(isset($_POST["search"]["value"]))
		{
			$query .= '
			WHERE tbl_student.student_name LIKE "%'.$_POST["search"]["value"].'%" 
			OR tbl_student.student_phone_number LIKE "%'.$_POST["search"]["value"].'%" 
			OR tbl_grade.grade_name LIKE "%'.$_POST["search"]["value"].'%" 
			';
		}

		if(isset($_POST["order"]))
		{
			$query .= '
			ORDER BY '.$_POST['order']['0']['column'].' '.$_POST['order']['0']['dir'].'
			';
		}
		else
		{
			$query .= '
			ORDER BY tbl_student.student_name ASC 
			';
		}
		if($_POST["length"] != -1)
		{
			$query .= 'LIMIT ' . $_POST['start'] . ', ' . $_POST['length'];
		}

		$statement = $connect->prepare($query);

		$statement->execute();
		$result = $statement->fetchAll();
		$data = array();
		$filtered_rows = $statement->rowCount();
		foreach($result as $row)
		{
			$sub_array = array();
			$sub_array[] = $row["student_name"];
			$sub_array[] = $row["student_phone_number"];
			$sub_array[] = $row["grade_name"];
            $sub_array[] = "₹".$row["total_fee"].".00";
            $sub_array[] = "₹".$row["paid_fee"].".00";
            $sub_array[] = "₹".$row["balance_fee"].".00";
			$sub_array[] = '<button type="button" name="view_student" class="btn btn-info btn-sm view_student" id="'.$row["student_id"].'">View</button>
							<button type="button" name="edit_student" class="btn btn-primary btn-sm edit_student" id="'.$row["student_id"].'">Take</button>
							';
			$data[] = $sub_array;
		}
        $condition ="
        join tbl_grade ON tbl_grade_fee_structure.fee_grade_id = tbl_grade.grade_id 
        JOIN tbl_student on tbl_grade_fee_structure.fee_grade_id = tbl_student.student_grade_id
        ";
		$output = array(
			"draw"				=>	intval($_POST["draw"]),
			"recordsTotal"		=> 	$filtered_rows,
			"recordsFiltered"	=>	get_total_records_condition($connect, 'tbl_grade_fee_structure',$condition),
			"data"				=>	$data
		);

		echo json_encode($output);
	}

	if($_POST["action"] == 'Add' || $_POST["action"] == "Edit")
	{
        $paid_amount = '';
		$comments = '';
		$error_paid_amount = '';
		$error_comments = '';
		$error = 0;

		if(empty($_POST["paid_amount"]))
		{
			$error_paid_amount = 'Please Enter the Amount';
			$error++;
		}
        elseif($_POST["paid_amount"] <= 0 ){
            $error_paid_amount = 'Please Enter Positive Amount ';
			$error++;
        }
		else
		{
			$paid_amount = $_POST["paid_amount"];
		}
		if(empty($_POST["comments"]))
		{
			$error_comments = $_POST["fee_student_id"];
			$error++;
		}
		else
		{
			$comments = $_POST["comments"];
		}
		$student_id = $_POST["student_id"];
		if($error > 0)
		{
			$output = array(
				'error'					=>	true,
				'error_paid_amount'		=>	$error_paid_amount,
				'error_comments'		=>	$error_comments,
			);
		}
		else
		{
			if($_POST["action"] == "Edit")
			{
                
				$data = array(
                    ':student_id'	=>	$_POST['fee_student_id'],
					':paid_amount'	=>	$paid_amount,	
					':comments'	    =>	$comments					
				);
				$query = "
				INSERT INTO tbl_fee_transactions 
				(student_id, paid_amount, comments) 
				VALUES (:student_id, :paid_amount, :comments)
				";
				$statement = $connect->prepare($query);
				if($statement->execute($data))
				{
					$output = array(
						'success'		=>	'Payment Added Successfully',
					);
				}
			}
        }
		echo json_encode($output);
	}

	if($_POST["action"] == "edit_fetch")
	{
        $GLOBALS['student_id']=$_POST["student_id"];
		$query = "
		SELECT * FROM tbl_student 
		WHERE student_id = '".$_POST["student_id"]."'
		";
		$statement = $connect->prepare($query);
		if($statement->execute())
		{
			$result = $statement->fetchAll();
			foreach($result as $row)
			{
				$output["student_name"] = $row["student_name"];
				$output["student_roll_number"] = $row["student_roll_number"];
				$output["student_grade_id"] = $row["student_grade_id"];
				$output["student_phone_number"] = $row["student_phone_number"];
				$output["student_id"] = $row["student_id"];
			}
			echo json_encode($output);
		}
	}
	if($_POST["action"] == "single_fetch")
	{	
		
		$value = Get_student_details($connect, $_POST["student_id"]);
		$query = "
		SELECT * FROM tbl_fee_transactions
		WHERE student_id = '".$_POST["student_id"]."' 
		";
		$statement = $connect->prepare($query);
		if($statement->execute())
		{
			$result = $statement->fetchAll();
			$row_count = $statement->rowCount();
			$output = '
			<div class="row">
            <div class="container ">
        <div class="row">
		<div class="col-sm-10 col-sm-offset-1">
			<div class="widget-box">
				<div class="widget-body">
					<div class="widget-main padding-24">
						<div class="row">
							<div class="col-sm-6">
								<div class="row">
									<div class="col-xs-11 label label-lg label-info badge">
										
									</div>
								</div>
								<div>
									<ul class="list-unstyled spaced">
										<li><b>Student Name    :</b> '.$value["student_name"].'</li>
                                        <li><b>Father Name     :</b> '.$value["student_father_name"].'</li>
                                        <li><b>Phone Number    :</b> '.$value["student_phone_number"].'</li>
                                        <li><b>Student Address :</b> '.$value["student_address"].'</li>	
                                        </br>
										<div><li class="divider"></li></div>
										<li>
											<i class="ace-icon fa fa-caret-right blue"></i>
											<u><h6>Paymant Transaction Infotmation:</h6></u>
										</li>
									</ul>
								</div>
							</div><!-- /.col -->
						</div><!-- /.row -->

						<div class="space"></div>

						<div>
							<table class="table table-striped table-bordered">
								<thead>
									<tr>
										<th>No.</th>
										<th>Payment Date</th>
										<th>Description</th>
										<th>Amount</th>
									</tr>
								</thead>
								<tbody>
			';
        if($row_count > 0){
			$value[] ='';
			$value = Get_student_fee_details($connect, $_POST["student_id"]);
			$count=1;
			foreach($result as $row)
			{
				$output .= '
				
									<tr>
										<td class="center">'.$count++.'</td>
										<td>'.$row["trans_date"].'</td>
										<td>'.$row["comments"].'</td>
										<td style="text-align: right;">₹'.$row["paid_amount"].'.00</td>
									</tr>
								';
			}
			$paid_fee = 0;
			$paid_fee = $value["paid_fee"];
			
			$output .= '
				
									<tr>
										<td colspan="3" style="text-align: center;" class="center">Total Amount Paid</td>
										<td style="text-align: right;color:green"> ₹'.$paid_fee.'.00</td>
									</tr>
			';
		}
		else {
			$output .= '
				
									<tr>
										<td colspan="4" style="text-align: center;" class="center">No Data Available</td>
									</tr>
			';
		}	
			@$total_fee = $value["total_fee"];
			@$balance_fee = ($total_fee - $value["paid_fee"] );
       		$output .= '
            					</tbody>
							</table>
						</div>
						<div class="row">
							<div >
								<h6 style="text-align: right; margin-left:15px;">
									Total Payment Amount :
									<span style="color:blue">₹'.$total_fee.'.00</span>
								</h6>
							</div>
                            <div style="text-align: right; margin-left:15px;">
								<h6 style="text-align: right"><div>
									Total Balance  Amount	: 
									<span style="color:red;text-align: right"> ₹'.$balance_fee.'.00</span></div>
								</h6>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
</div>';
			echo $output;
		}
	}

	if($_POST["action"] == "delete")
	{
		$query = "
		slect * FROM tbl_student 
		WHERE student_id = '".$_POST["student_id"]."'
		";
		$statement = $connect->prepare($query);
		if($statement->execute())
		{
			echo 'Data Delete Successfully';
		}
	}
}

?>