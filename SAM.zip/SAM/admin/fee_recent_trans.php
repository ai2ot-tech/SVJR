<?php
//student.php
include('header.php');
?>
<div class="container" style="margin-top:30px">
  <div class="card">
  	<div class="card-header">
      <div class="row">
        <div class="col-md-9">Recent Fee Transactions</div>
        <div class="col-md-3" allign="right" >
        	<label type="button" id="add_button" class="btn btn-success btn-sm">Total Today</label>
            <label type="button" id="add_button" class="btn btn-info btn-sm">Total Transactions</label>
        </div>
      </div>
    </div>
  	<div class="card-body">
  		<div class="table-responsive">
        	<span id="message_operation"></span>
        	<table class="table table-striped table-bordered" id="student_table">
  				<thead class="thead-dark">
  					<tr>            
  						<th>Student Name</th>
  						<th>Phone Number</th>
                        <th>Grade Name</th>
  						<th>Transaction Date</th>
                        <th>Amount Paid</th>
                        <th>Payment Remarks</th>
  					</tr>
  				</thead>
  				<tbody>

  				</tbody>
  			</table>
  			
  		</div>
  	</div>
  </div>
</div>

</body>
</html>

<script type="text/javascript" src="../js/bootstrap-datepicker.js"></script>
<link rel="stylesheet" href="../css/datepicker.css" />



<script>
$(document).ready(function(){
	
	var dataTable = $('#student_table').DataTable({
		"processing":true,
		"serverSide":true,
		"order":[],
    'columnDefs': [ {
        'targets': [0], // column index (start from 0)
        'orderable': false, // set orderable false for selected columns
     }],
		"ajax":{
			url:"fee_structure_action.php",
			method:"POST",
			data:{action:'fetch_transactions'},
		}
	}); 

 
});
</script>