<?php

//student.php

include('header.php');

?>

<div class="container" style="margin-top:30px">
  <div class="card">
  	<div class="card-header">
      <div class="row">
        <div class="col-md-9">Fee Structure</div>
        <div class="col-md-3" align="right">
        	<button type="button" id="add_button" class="btn btn-info btn-sm">Add</button>
        </div>
      </div>
    </div>
  	<div class="card-body">
  		<div class="table-responsive">
        	<span id="message_operation"></span>
        	<table class="table table-striped table-bordered" id="student_table">
  				<thead class="thead-dark">
  					<tr>            
  						<th>Grade</th>
  						<th>School Fee</th>
              <th>Hostel Fee</th>
  						<th>Tution Fee</th>
              <th>Misc Fee</th>
              <th>Fee Description</th>
              <th>Action</th>
  					</tr>
  				</thead>
  				<tbody>

  				</tbody>
  			</table>
  			
  		</div>
  	</div>
  </div>
</div>

</body>
</html>

<script type="text/javascript" src="../js/bootstrap-datepicker.js"></script>
<link rel="stylesheet" href="../css/datepicker.css" />

<style>
    .datepicker {
      z-index: 1600 !important; /* has to be larger than 1050 */
    }
</style>

<div class="modal" id="formModal">
  <div class="modal-dialog">
  	<form method="post" id="fee_form">
      <div class="modal-content">

        <!-- Modal Header -->
        <div class="modal-header">
          <h4 class="modal-title" id="modal_title"></h4>
          <button type="button" class="close" data-dismiss="modal">&times;</button>
        </div>

        <!-- Modal body -->
        <div class="modal-body">
        <div class="form-group">
            <div class="row">
              <label class="col-md-4 text-left">Grade <span class="text-danger">*</span></label>
              <div class="col-md-8">
                <select name="fee_grade_id" id="fee_grade_id" class="form-control">
                  <option value="">Select Grade</option>
                  <?php
                  echo load_grade_list_fee($connect);
                  ?>
              </select>
              <span id="error_fee_grade_id" class="text-danger"></span>
              </div>
            </div>
          </div>
          <div class="form-group">
            <div class="row" >
              <label class="col-md-4 text-left">School Fee <span class="text-danger">*</span></label>
              <div class="col-md-8">
                <input type="number" name="school_fee" id="school_fee" class="form-control" />
                <span id="error_school_fee" class="text-danger"></span>
              </div>
            </div>
          </div>
          <div class="form-group">
            <div class="row" >
              <label class="col-md-4 text-left">Hostal Fee <span class="text-danger">*</span></label>
              <div class="col-md-8">
                <input type="number" name="hostel_fee" id="hostel_fee" class="form-control" />
                <span id="error_hostel_fee" class="text-danger"></span>
              </div>
            </div>
          </div>
          <div class="form-group">
            <div class="row" >
              <label class="col-md-4 text-left">Tution Fee <span class="text-danger">*</span></label>
              <div class="col-md-8">
                <input type="number" name="tution_fee" id="tution_fee" class="form-control" />
                <span id="error_tution_fee" class="text-danger"></span>
              </div>
            </div>
          </div>
          <div class="form-group">
            <div class="row" >
              <label class="col-md-4 text-left">Misc Fee <span class="text-danger">*</span></label>
              <div class="col-md-8">
                <input type="number" name="misc_fee" id="misc_fee" class="form-control" />
                <span id="error_misc_fee" class="text-danger"></span>
              </div>
            </div>
          </div>
          
          <div class="form-group">
            <div class="row">
              <label class="col-md-4 text-left">Fee Description <span class="text-danger">*</span></label>
              <div class="col-md-8">
                <textarea name="fee_desc" id="fee_desc" class="form-control"></textarea>
                <span id="error_fee_desc" class="text-danger"></span>
              </div>
            </div>
          </div>
          <div class="form-group">
            <div class="row">
              
            </div>
          </div>
        </div>

        <!-- Modal footer -->
        <div class="modal-footer">
        	<input type="hidden" name="grade_id" id="grade_id" />
        	<input type="hidden" name="action" id="action" value="Add" />
        	<input type="submit" name="button_action" id="button_action" class="btn btn-success btn-sm" value="Add" />
          	<button type="button" class="btn btn-danger btn-sm" data-dismiss="modal">Close</button>
        </div>

      </div>
  </form>
  </div>
</div>

<div class="modal" id="deleteModal">
  <div class="modal-dialog">
    <div class="modal-content">

      <!-- Modal Header -->
      <div class="modal-header">
        <h4 class="modal-title">Delete Confirmation</h4>
        <button type="button" class="close" data-dismiss="modal">&times;</button>
      </div>

      <!-- Modal body -->
      <div class="modal-body">
        <h3 align="center">Are you sure you want to remove this?</h3>
      </div>

      <!-- Modal footer -->
      <div class="modal-footer">
        <button type="button" name="ok_button" id="ok_button" class="btn btn-primary btn-sm">OK</button>
        <button type="button" class="btn btn-danger btn-sm" data-dismiss="modal">Close</button>
      </div>

    </div>
  </div>
</div>


<script>
$(document).ready(function(){
	
	var dataTable = $('#student_table').DataTable({
		"processing":true,
		"serverSide":true,
		"order":[],
    'columnDefs': [ {
        'targets': [0], // column index (start from 0)
        'orderable': false, // set orderable false for selected columns
     }],
		"ajax":{
			url:"fee_structure_action.php",
			method:"POST",
			data:{action:'fetch'},
		}
	});

	function clear_field()
	{
		$('#fee_form')[0].reset();
		$('#error_fee_grade_id').text('');
		$('#error_school_fee').text('');
		$('#error_hostel_fee').text('');
		$('#error_tution_fee').text('');
    $('#error_misc_fee').text('');
    $('#error_fee_desc').text('');
	}

	$('#add_button').click(function(){
		$('#modal_title').text('Add Grade Fee Structure');
		$('#button_action').val('Add');
		$('#action').val('Add');
		$('#formModal').modal('show');
		clear_field();
	});

	$('#fee_form').on('submit', function(event){
		event.preventDefault();
		$.ajax({
			url:"fee_structure_action.php",
			method:"POST",
			data:$(this).serialize(),
			dataType:"json",
			beforeSend:function(){
				$('#button_action').val('Validate...');
				$('#button_action').attr('disabled', 'disabled');
			},
			success:function(data)
			{
				$('#button_action').attr('disabled', false);
				$('#button_action').val($('#action').val());
				if(data.success)
				{
					$('#message_operation').html('<div class="alert alert-success">'+data.success+'</div>');
					clear_field();
					$('#formModal').modal('hide');
					dataTable.ajax.reload();
				}
				if(data.error)
				{
					if(data.error_fee_grade_id != '')
					{
						$('#error_fee_grade_id').text(data.error_fee_grade_id);
					}
					else
					{
						$('#error_fee_grade_id').text('');
					}
					if(data.error_school_fee != '')
					{
						$('#error_school_fee').text(data.error_school_fee);
					}
					else
					{
						$('#error_school_fee').text('');
					}
					if(data.error_tution_fee != '')
					{
						$('#error_tution_fee').text(data.error_tution_fee);
					}
					else
					{
						$('#error_tution_fee').text('');
					}
					if(data.error_hostel_fee != '')
					{
						$('#error_hostel_fee').text(data.error_hostel_fee);
					}
					else
					{
						$('#error_hostel_fee').text('');
					}
          
          if(data.error_misc_fee != '')
					{
						$('#error_misc_fee').text(data.error_misc_fee);
					}
					else
					{
						$('#error_misc_fee').text('');
					}
          if(data.error_fee_desc != '')
					{
						$('#error_fee_desc').text(data.error_fee_desc);
					}
					else
					{
						$('#error_fee_desc').text('');
					}
				}
			}
		})
	});

  var fee_grade_id = '';

  $(document).on('click', '.edit_fee', function(){
    fee_grade_id = $(this).attr('id');
    clear_field();
    $.ajax({
      url:"fee_structure_action.php",
      method:"POST",
      data:{action:'edit_fetch', fee_grade_id:fee_grade_id},
      dataType:"json",
      success:function(data)
      {
        $('#fee_grade_id').val(data.fee_grade_id);
        $('#school_fee').val(data.school_fee);
        $('#hostel_fee').val(data.hostel_fee);
        $('#tution_fee').val(data.tution_fee);
        $('#misc_fee').val(data.misc_fee);
        $('#fee_desc').val(data.fee_desc);
        $('#modal_title').text('Edit Fee Structure');
        $('#button_action').val('Edit');
        $('#action').val('Edit');
        $('#formModal').modal('show');
      }
    })
  });

  $(document).on('click', '.delete_fee', function(){
    fee_grade_id = $(this).attr('id');
    $('#deleteModal').modal('show');
  });

  $('#ok_button').click(function(){
    $.ajax({
      url:"fee_structure_action.php",
      method:"POST",
      data:{fee_grade_id:fee_grade_id, action:"delete"},
      success:function(data)
      {
        $('#message_operation').html('<div class="alert alert-success">'+data+'</div>');
        $('#deleteModal').modal('hide');
        dataTable.ajax.reload();
      }
    })
  });

});
</script>