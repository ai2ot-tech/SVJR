<?php

//student_action.php

include('database_connection.php');

session_start();

if(isset($_POST["action"]))
{
	if($_POST["action"] == "fetch")
	{
		$query = "
		SELECT * FROM tbl_grade_fee_structure JOIN
		tbl_grade on tbl_grade.grade_id = tbl_grade_fee_structure.fee_grade_id 
		";

		if(isset($_POST["search"]["value"]))
		{
			$query .= '
			WHERE tbl_grade_fee_structure.school_fee LIKE "%'.$_POST["search"]["value"].'%" 
			OR tbl_grade_fee_structure.school_fee LIKE "%'.$_POST["search"]["value"].'%"
			OR tbl_grade_fee_structure.hostel_fee LIKE "%'.$_POST["search"]["value"].'%"
			OR tbl_grade_fee_structure.tution_fee LIKE "%'.$_POST["search"]["value"].'%"
			OR tbl_grade_fee_structure.misc_fee LIKE "%'.$_POST["search"]["value"].'%"
			OR tbl_grade.grade_name LIKE "%'.$_POST["search"]["value"].'%"
			';
		}

		if(isset($_POST["order"]))
		{
			$query .= '
			ORDER BY '.$_POST['order']['0']['column'].' '.$_POST['order']['0']['dir'].'
			';
		}
		else
		{
			$query .= '
			ORDER BY tbl_grade.grade_name ASC 
			';
		}
		if($_POST["length"] != -1)
		{
			$query .= 'LIMIT ' . $_POST['start'] . ', ' . $_POST['length'];
		}

		$statement = $connect->prepare($query);

		$statement->execute();
		$result = $statement->fetchAll();
		$data = array();
		$filtered_rows = $statement->rowCount();
		foreach($result as $row)
		{
			$sub_array = array();
			$sub_array[] = $row["grade_name"];
			$sub_array[] = $row["school_fee"];
			$sub_array[] = $row["hostel_fee"];
            $sub_array[] = $row["tution_fee"];
            $sub_array[] = $row["misc_fee"];
            $sub_array[] = $row["fee_desc"];
			$sub_array[] = '<button type="button" name="edit_fee" class="btn btn-primary btn-sm edit_fee" id="'.$row["fee_grade_id"].'"> Edit </button>
							<button type="button" name="delete_fee" class="btn btn-danger btn-sm delete_fee" id="'.$row["fee_grade_id"].'">Delete</button>';
			$data[] = $sub_array;
		}
		$output = array(
			"draw"				=>	intval($_POST["draw"]),
			"recordsTotal"		=> 	$filtered_rows,
			"recordsFiltered"	=>	get_total_records($connect, 'tbl_grade_fee_structure'),
			"data"				=>	$data
		);

		echo json_encode($output);
	}
	if($_POST["action"] == "fetch_transactions")
	{
		$query = "
		SELECT grade_name,tbl_student.*,paid_amount,trans_date,comments FROM tbl_fee_transactions JOIN tbl_student 
		ON tbl_student.student_id = tbl_fee_transactions.student_id JOIN tbl_grade 
		ON tbl_grade.grade_id=tbl_student.student_grade_id
		";

		if(isset($_POST["search"]["value"]))
		{
			$query .= '
			WHERE tbl_student.student_name LIKE "%'.$_POST["search"]["value"].'%" 
			OR tbl_fee_transactions.trans_date LIKE "%'.$_POST["search"]["value"].'%"
			OR tbl_grade.grade_name LIKE "%'.$_POST["search"]["value"].'%"
			OR tbl_fee_transactions.comments LIKE "%'.$_POST["search"]["value"].'%"
			OR tbl_student.student_phone_number LIKE "%'.$_POST["search"]["value"].'%"
			';
		}

		if(isset($_POST["order"]))
		{
			$query .= '
			ORDER BY '.$_POST['order']['0']['column'].' '.$_POST['order']['0']['dir'].'
			';
		}
		else
		{
			$query .= '
			ORDER BY tbl_fee_transactions.trans_date DESC 
			';
		}
		if($_POST["length"] != -1)
		{
			$query .= 'LIMIT ' . $_POST['start'] . ', ' . $_POST['length'];
		}

		$statement = $connect->prepare($query);

		$statement->execute();
		$result = $statement->fetchAll();
		$data = array();
		$filtered_rows = $statement->rowCount();
		foreach($result as $row)
		{
			$sub_array = array();
			$sub_array[] = $row["student_name"];
			$sub_array[] = $row["student_phone_number"];
			$sub_array[] = $row["grade_name"];
			$sub_array[] = $row["trans_date"];
            $sub_array[] = "₹".$row["paid_amount"].".00";
            $sub_array[] = $row["comments"];
            
			$data[] = $sub_array;
		}
		$output = array(
			"draw"				=>	intval($_POST["draw"]),
			"recordsTotal"		=> 	$filtered_rows,
			"recordsFiltered"	=>	get_total_records($connect, 'tbl_fee_transactions'),
			"data"				=>	$data
		);

		echo json_encode($output);
	}
	if($_POST["action"] == 'Add' || $_POST["action"] == "Edit")
	{
		$fee_grade_id = '';
		$school_fee= '';
		$hostel_fee= '';
		$tution_fee= '';
    	$misc_fee= '';
    	$fee_desc= '';
		$error_fee_grade_id= '';
		$error_school_fee= '';
		$error_hostel_fee= '';
		$error_tution_fee= '';
    	$error_misc_fee= '';
    	$error_fee_desc= '';
		$error = 0;

		if(empty($_POST["fee_grade_id"]))
		{
			$error_fee_grade_id = 'Please Select the grade';
			$error++;
		}
		else
		{
			$fee_grade_id = $_POST["fee_grade_id"];
		}
		if(empty($_POST["school_fee"]))
		{
			$error_school_fee = 'School fee is required';
			$error++;
		}
		else
		{								
			$school_fee = $_POST["school_fee"];			
		}
		if(empty($_POST["hostel_fee"]))
		{
			$error_hostel_fee = 'hostel fee is required';
			$error++;
		}
		else
		{
			$hostel_fee = $_POST["hostel_fee"];
		}
		if(empty($_POST["tution_fee"]))
		{
			$error_tution_fee = "Tution fee is required";
			$error++;
		}
		else
		{
			$tution_fee = $_POST["tution_fee"];
		}
		if(empty($_POST["misc_fee"]))
		{
			$error_misc_fee = "Please type 0 if empty";
			$error++;
		}
		else
		{
			$misc_fee = $_POST["misc_fee"];
		}
		if(empty($_POST["fee_desc"]))
		{
			$error_fee_desc = "Give Description About FEE";
			$error++;
		}
		else
		{
			$fee_desc = $_POST["fee_desc"];
		}
		if($error > 0)
		{
			$output = array(
				'error'				=>	true,
				'error_fee_grade_id'=>		$error_fee_grade_id,
				'error_school_fee'	=>		$error_school_fee,
				'error_hostel_fee'	=>		$error_hostel_fee,
				'error_tution_fee'	=>		$error_tution_fee,
    			'error_misc_fee'	=>		$error_misc_fee,
    			'error_fee_desc'	=>		$error_fee_desc
			);
		}
		else
		{
			if($_POST["action"] == 'Add')
			{
				$data = array(
					':fee_grade_id'	=>		$fee_grade_id,
					':school_fee'	=>		$school_fee,
					':hostel_fee'	=>		$hostel_fee,
					':tution_fee'	=>		$tution_fee,
    				':misc_fee'		=>		$misc_fee,
    				':fee_desc'		=>		$fee_desc
				);
				$query = "
				INSERT INTO tbl_grade_fee_structure 
				(fee_grade_id, school_fee, hostel_fee, tution_fee, misc_fee, fee_desc) 
				VALUES (:fee_grade_id, :school_fee, :hostel_fee, :tution_fee, :misc_fee, :fee_desc)
				";

				$statement = $connect->prepare($query);
				if($statement->execute($data))
				{
					$output = array(
						'success'		=>	'Data Added Successfully',
					);
				}
			}
			if($_POST["action"] == "Edit")
			{
				$data = array(
					':fee_grade_id'		=>		$fee_grade_id,
					':school_fee'		=>		$school_fee,
					':hostel_fee'		=>		$hostel_fee,
					':tution_fee'		=>		$tution_fee,
    				':misc_fee'			=>		$misc_fee,
    				':fee_desc'			=>		$fee_desc
				);
				$query = "
				UPDATE tbl_grade_fee_structure 
				SET  
				school_fee = :school_fee, 
				hostel_fee = :hostel_fee, 
				tution_fee = :tution_fee,
				misc_fee = :misc_fee,
				fee_desc = :fee_desc
				WHERE fee_grade_id = :fee_grade_id
				";
				$statement = $connect->prepare($query);
				if($statement->execute($data))
				{
					$output = array(
						'success'		=>	'Data Edited Successfully',
					);
				}
			}
		}
		echo json_encode($output);
	}

	if($_POST["action"] == "edit_fetch")
	{
		$query = "
		SELECT * FROM tbl_grade_fee_structure 
		WHERE fee_grade_id = '".$_POST["fee_grade_id"]."'
		";
		$statement = $connect->prepare($query);
		if($statement->execute())
		{
			$result = $statement->fetchAll();
			foreach($result as $row)
			{
				$output["fee_grade_id"] = $row["fee_grade_id"];
				$output["school_fee"] = $row["school_fee"];
				$output["hostel_fee"] = $row["hostel_fee"];
				$output["tution_fee"] = $row["tution_fee"];
				$output["misc_fee"] = $row["misc_fee"];
				$output["fee_desc"] = $row["fee_desc"];
			}
			echo json_encode($output);
		}
	}
	

	if($_POST["action"] == "delete")
	{
		$query = "
		DELETE FROM tbl_grade_fee_structure 
		WHERE fee_grade_id = '".$_POST["fee_grade_id"]."'
		";
		$statement = $connect->prepare($query);
		if($statement->execute())
		{
			echo 'Fee Structure Deleted Successfully';
		}
	}
}

?>