<?php

//subject_action.php

include('database_connection.php');
session_start();
$output='';
if(isset($_POST["action"]))
{
	if($_POST["action"] == "fetch")
	{
		$query = "SELECT * FROM tbl_subject ";
		if(isset($_POST["search"]["value"]))
		{
			$query .= 'WHERE subject_name LIKE "%'.$_POST["search"]["value"].'%" OR 
             subject_code LIKE "%'.$_POST["search"]["value"].'%" OR 
             subject_desc LIKE "%'.$_POST["search"]["value"].'%" 
            ';
		}
		if(isset($_POST["order"]))
		{
			$query .= 'ORDER BY '.$_POST['order']['0']['column'].' '.$_POST['order']['0']['dir'].' ';
		}
		else
		{
			$query .= 'ORDER BY subject_grade_id DESC ';
		}
		if($_POST["length"] != -1)
		{
			$query .= 'LIMIT ' . $_POST['start'] . ', ' . $_POST['length'];
		}

		$statement = $connect->prepare($query);
		$statement->execute();
		$result = $statement->fetchAll();
		$data = array();
		$filtered_rows = $statement->rowCount();
		foreach($result as $row)
		{
			$sub_array = array();
			$sub_array[] = Get_grade_name($connect, $row["subject_grade_id"]);
            $sub_array[] = $row["subject_name"];
            $sub_array[] = $row["subject_code"];
            $sub_array[] = $row["subject_desc"];
			$sub_array[] = '<button type="button" name="edit_subject" class="btn btn-primary btn-sm edit_subject" id="'.$row["subject_id"].'">Edit</button>
							<button type="button" name="delete_subject" class="btn btn-danger btn-sm delete_subject" id="'.$row["subject_id"].'">Delete</button>';
			$data[] = $sub_array;
		}

		$output = array(
			"draw"			=>	intval($_POST["draw"]),
			"recordsTotal"		=> 	$filtered_rows,
			"recordsFiltered"	=>	get_total_records($connect, 'tbl_subject'),
			"data"				=>	$data
		);

		
	}
	if($_POST["action"] == 'Add' || $_POST["action"] == "Edit")
	{
		$subject_name = '';
		$error_subject_name = '';
        $subject_code = '';
        $error_subject_code = '';
		$subject_grade_id = '';
		$error_subject_grade_id = '';
		$subject_desc = '';
		$error_subject_desc = '';
		$error = 0;
        if(empty($_POST["subject_code"]))
		{
			$error_subject_code = 'Subject Code is required';
			$error++;
		}
		else
		{
			$subject_code = $_POST["subject_code"];
		}
		if(empty($_POST["subject_name"]))
		{
			$error_subject_name = 'Subject Name is required';
			$error++;
		}
		else
		{
			$subject_name = $_POST["subject_name"];
		}
        
        if(empty($_POST["subject_grade_id"]))
		{
			$error_subject_grade_id = 'Please select Grade';
			$error++;
		}
		else
		{
			$subject_grade_id = $_POST["subject_grade_id"];
		}
        if(empty($_POST["subject_desc"]))
		{
			$error_subject_desc = 'Subject Description is required';
			$error++;
		}
		else
		{
			$subject_desc = $_POST["subject_desc"];
		}
		if($error > 0)
		{
			$output = array(
				'error'							=>	true,
				'error_subject_name'			=>	$error_subject_name,
                'error_subject_code'            =>  $error_subject_code,
                'error_subject_grade_id'        =>  $error_subject_grade_id,
                'error_subject_desc'            =>  $error_subject_desc
			);
		}
		else
		{
			$subject_id = $_POST["unique_subject_id"];
			if($_POST["action"] == "Add")
			{
				$data = array(
					':subject_code'				=>	$subject_code,
                    ':subject_name'             =>  $subject_name,
                    ':subject_grade_id'         =>  $subject_grade_id,
                    ':subject_desc'             =>  $subject_desc
				);
				$query = "
				INSERT INTO tbl_subject 
				(subject_code,subject_name,subject_grade_id,subject_desc) 
			    VALUES 
                (:subject_code, :subject_name, :subject_grade_id, :subject_desc) 
				";
				$statement = $connect->prepare($query);
				if($statement->execute($data))
				{
					$output = array(
						'success'		=>	'Data Added Successfully',
					);
				}
			}
			if($_POST["action"] == "Edit")
			{
				
				$data = array(
					':subject_code'			=>	$subject_code,
                    ':subject_name'         =>  $subject_name,
                    ':subject_grade_id'     =>  $subject_grade_id,
                    ':subject_desc'         =>  $subject_desc,
					':subject_id'			=>	$subject_id
				);
				$query = "
				UPDATE tbl_subject 
				SET subject_name = :subject_name ,subject_code = :subject_code, subject_grade_id = :subject_grade_id,subject_desc = :subject_desc
				WHERE subject_id = :subject_id
				";
				$statement = $connect->prepare($query);
				if($statement->execute($data))
				{
					$output = array(
						'success'		=>	'Data Edited Successfully',
					);
				}
			}
		}
	}
	
	if($_POST["action"] == "delete")
	{
		$query = "
		DELETE FROM tbl_subject 
		WHERE subject_id = '".$_POST["subject_id"]."'
		";
		$statement = $connect->prepare($query);
		if($statement->execute())
		{
			echo 'Data Deleted Successfully';
		}
		$output='';
	}
	if($_POST["action"] == "edit_fetch")
	{
		$query = "
		SELECT * FROM tbl_subject 
		WHERE subject_id = '".$_POST["subject_id"]."'
		";
		$statement = $connect->prepare($query);
		if($statement->execute())
		{
			$result = $statement->fetchAll();
			foreach($result as $row)
			{
				$output["subject_id"] = $row["subject_id"];
				$output["subject_name"] = $row["subject_name"];
				$output["subject_code"] = $row["subject_code"];
                $output["subject_desc"] = $row["subject_desc"];
                $output["subject_grade_id"] = $row["subject_grade_id"];
			}
		}
	}
	
	echo json_encode($output);	
}

?>