<?php
include('database_connection.php');

session_start();
$student_id=24;
$value = Get_student_fee_details($connect, $student_id);
        echo $value["paid_fee"];
		echo $value["total_fee"];
		echo $value["balance_fee"];
		

/*
SELECT student_name,student_phone_number,fee.grade_id,(school_fee+hostel_fee+tution_fee+misc_fee) as Total_fee 
FROM `tbl_grade_fee_structure` fee join tbl_grade grade
ON fee.grade_id = grade.grade_id
JOIN tbl_student on fee.grade_id = tbl_student.student_grade_id

SELECT grade.grade_name,tbl_student.student_id,student_name,student_phone_number,fee.fee_grade_id,(school_fee+hostel_fee+tution_fee+misc_fee) as Total_fee,
(select sum(paid_amount) from tbl_fee_transactions where student_id = tbl_student.student_id) as amount_paid,
((school_fee+hostel_fee+tution_fee+misc_fee) - (select sum(paid_amount) from tbl_fee_transactions where student_id = tbl_student.student_id)) as balance
FROM `tbl_grade_fee_structure` fee join tbl_grade grade
ON fee.fee_grade_id = grade.grade_id
JOIN tbl_student on fee.fee_grade_id = tbl_student.student_grade_id
*/
?>
