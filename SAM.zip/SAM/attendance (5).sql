-- phpMyAdmin SQL Dump
-- version 5.0.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 13, 2021 at 11:34 AM
-- Server version: 10.4.17-MariaDB
-- PHP Version: 8.0.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `attendance`
--

-- --------------------------------------------------------

--
-- Table structure for table `tbl_absent_today`
--

CREATE TABLE `tbl_absent_today` (
  `student_id` int(11) NOT NULL DEFAULT 0,
  `student_name` varchar(150) CHARACTER SET latin1 NOT NULL,
  `student_address` varchar(255) CHARACTER SET latin1 NOT NULL,
  `student_roll_number` int(11) NOT NULL,
  `student_dob` date NOT NULL,
  `student_phone_number` int(14) DEFAULT NULL,
  `student_grade_id` int(11) NOT NULL,
  `teacher_id` int(11) NOT NULL DEFAULT 0,
  `teacher_name` varchar(150) CHARACTER SET latin1 NOT NULL,
  `teacher_address` text CHARACTER SET latin1 NOT NULL,
  `teacher_emailid` varchar(100) CHARACTER SET latin1 NOT NULL,
  `teacher_password` varchar(100) CHARACTER SET latin1 NOT NULL,
  `teacher_qualification` varchar(100) CHARACTER SET latin1 NOT NULL,
  `teacher_doj` date NOT NULL,
  `teacher_image` varchar(100) CHARACTER SET latin1 NOT NULL,
  `teacher_grade_id` int(11) NOT NULL,
  `grade_id` int(11) NOT NULL DEFAULT 0,
  `grade_name` varchar(10) CHARACTER SET latin1 NOT NULL,
  `attendance_id` int(11) NOT NULL DEFAULT 0,
  `attendance_status` enum('Present','Absent') CHARACTER SET latin1 NOT NULL,
  `attendance_date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_absent_today`
--

INSERT INTO `tbl_absent_today` (`student_id`, `student_name`, `student_address`, `student_roll_number`, `student_dob`, `student_phone_number`, `student_grade_id`, `teacher_id`, `teacher_name`, `teacher_address`, `teacher_emailid`, `teacher_password`, `teacher_qualification`, `teacher_doj`, `teacher_image`, `teacher_grade_id`, `grade_id`, `grade_name`, `attendance_id`, `attendance_status`, `attendance_date`) VALUES
(7, 'Sally Luna', '', 1, '2003-12-19', NULL, 2, 6, 'Ramya', 'Durgacamp', 'ramya@gmail.com', '$2y$10$i3CUalQ.tw7yXodt77qUEugD14xm6hay0rUzrndS/QkEJJKYRiLLC', 'BA', '2020-10-06', '609d4c9ddc17d.jpg', 2, 2, '11 - B', 216, 'Absent', '2021-05-14'),
(11, 'Minnie Morris', '', 5, '2003-06-18', NULL, 2, 6, 'Ramya', 'Durgacamp', 'ramya@gmail.com', '$2y$10$i3CUalQ.tw7yXodt77qUEugD14xm6hay0rUzrndS/QkEJJKYRiLLC', 'BA', '2020-10-06', '609d4c9ddc17d.jpg', 2, 2, '11 - B', 220, 'Absent', '2021-05-14');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_admin`
--

CREATE TABLE `tbl_admin` (
  `admin_id` int(11) NOT NULL,
  `admin_user_name` varchar(100) NOT NULL,
  `admin_password` varchar(150) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_admin`
--

INSERT INTO `tbl_admin` (`admin_id`, `admin_user_name`, `admin_password`) VALUES
(1, 'admin', '$2y$10$EtB/BJlp/ZbDCM1bYGzhUu.kh4W7a6lQhWPOdWmKmBb1HjbTJWmWi');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_attendance`
--

CREATE TABLE `tbl_attendance` (
  `attendance_id` int(11) NOT NULL,
  `student_id` int(11) NOT NULL,
  `attendance_status` enum('Present','Absent') NOT NULL,
  `attendance_date` date NOT NULL,
  `teacher_id` int(11) NOT NULL,
  `grade_id` int(25) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_attendance`
--

INSERT INTO `tbl_attendance` (`attendance_id`, `student_id`, `attendance_status`, `attendance_date`, `teacher_id`, `grade_id`) VALUES
(1, 7, 'Present', '2021-06-04', 8, 2),
(2, 8, 'Absent', '2021-06-04', 8, 2),
(3, 9, 'Present', '2021-06-04', 8, 2),
(4, 10, 'Absent', '2021-06-04', 8, 2),
(5, 11, 'Present', '2021-06-04', 8, 2),
(6, 25, 'Present', '2021-06-04', 8, 2),
(7, 7, 'Present', '2021-06-05', 8, 2),
(8, 8, 'Present', '2021-06-05', 8, 2),
(9, 9, 'Present', '2021-06-05', 8, 2),
(10, 10, 'Absent', '2021-06-05', 8, 2),
(11, 11, 'Present', '2021-06-05', 8, 2),
(12, 25, 'Absent', '2021-06-05', 8, 2),
(13, 1, 'Present', '2021-06-04', 8, 1),
(14, 3, 'Present', '2021-06-04', 8, 1),
(15, 4, 'Absent', '2021-06-04', 8, 1),
(16, 5, 'Present', '2021-06-04', 8, 1),
(17, 6, 'Present', '2021-06-04', 8, 1),
(18, 24, 'Absent', '2021-06-04', 8, 1),
(19, 1, 'Present', '2021-06-05', 8, 1),
(20, 3, 'Absent', '2021-06-05', 8, 1),
(21, 4, 'Present', '2021-06-05', 8, 1),
(22, 5, 'Absent', '2021-06-05', 8, 1),
(23, 6, 'Present', '2021-06-05', 8, 1),
(24, 24, 'Absent', '2021-06-05', 8, 1),
(25, 1, 'Absent', '2021-06-03', 8, 1),
(26, 3, 'Present', '2021-06-03', 8, 1),
(27, 4, 'Present', '2021-06-03', 8, 1),
(28, 5, 'Absent', '2021-06-03', 8, 1),
(29, 6, 'Present', '2021-06-03', 8, 1),
(30, 24, 'Present', '2021-06-03', 8, 1);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_fee_transactions`
--

CREATE TABLE `tbl_fee_transactions` (
  `trans_id` int(11) NOT NULL,
  `student_id` int(11) NOT NULL,
  `paid_amount` int(11) NOT NULL,
  `trans_date` datetime NOT NULL DEFAULT current_timestamp(),
  `comments` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_fee_transactions`
--

INSERT INTO `tbl_fee_transactions` (`trans_id`, `student_id`, `paid_amount`, `trans_date`, `comments`) VALUES
(1, 24, 25000, '2021-06-11 00:00:00', 'test'),
(2, 24, 5000, '2021-06-11 00:00:00', 'test1'),
(3, 6, 5000, '2021-06-11 00:00:00', 'test1'),
(5, 24, 1000, '2021-06-11 14:29:30', 'again'),
(17, 0, 1234, '2021-06-11 19:04:45', 'sdf'),
(18, 24, 1000, '2021-06-12 11:32:59', 'NEFT'),
(19, 6, 2000, '2021-06-12 11:34:05', 'NEFT'),
(20, 25, 20000, '2021-06-12 17:35:08', 'NEFT'),
(21, 25, 5000, '2021-06-13 14:41:31', 'DD');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_grade`
--

CREATE TABLE `tbl_grade` (
  `grade_id` int(11) NOT NULL,
  `grade_name` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_grade`
--

INSERT INTO `tbl_grade` (`grade_id`, `grade_name`) VALUES
(1, '11 - A'),
(2, '11 - B'),
(3, '12 - A'),
(4, '12 - B'),
(5, '11 - C'),
(7, '12 - C');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_grade_fee_structure`
--

CREATE TABLE `tbl_grade_fee_structure` (
  `fee_grade_id` int(11) NOT NULL,
  `school_fee` int(11) NOT NULL,
  `hostel_fee` int(11) NOT NULL,
  `tution_fee` int(11) NOT NULL,
  `misc_fee` int(11) NOT NULL,
  `fee_desc` longtext NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_grade_fee_structure`
--

INSERT INTO `tbl_grade_fee_structure` (`fee_grade_id`, `school_fee`, `hostel_fee`, `tution_fee`, `misc_fee`, `fee_desc`) VALUES
(1, 12000, 25000, 5000, 2000, 'DESCRI\r\n'),
(2, 10000, 25000, 5000, 3000, 'Expailnation about Fee structure'),
(3, 13000, 24000, 3000, 1500, 'Structure'),
(4, 13000, 30000, 5000, 2000, 'jfdjyrc,ljfdjsdfliudfik\r\nuydfiukfkg\r\nludfkufdj'),
(5, 13000, 25000, 6000, 1500, 'Grade 11.c\r\nDescription');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_student`
--

CREATE TABLE `tbl_student` (
  `student_id` int(11) NOT NULL,
  `student_name` varchar(150) NOT NULL,
  `student_address` varchar(255) NOT NULL,
  `student_roll_number` int(11) NOT NULL,
  `student_dob` date NOT NULL,
  `student_gender` enum('Male','Female') NOT NULL,
  `student_father_name` varchar(45) DEFAULT NULL,
  `student_mother_name` varchar(45) DEFAULT NULL,
  `student_phone_number` bigint(14) DEFAULT NULL,
  `student_aadhar_number` bigint(25) DEFAULT NULL,
  `student_grade_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_student`
--

INSERT INTO `tbl_student` (`student_id`, `student_name`, `student_address`, `student_roll_number`, `student_dob`, `student_gender`, `student_father_name`, `student_mother_name`, `student_phone_number`, `student_aadhar_number`, `student_grade_id`) VALUES
(1, 'Edward Hedberg', '', 1, '2003-03-04', 'Male', NULL, NULL, NULL, NULL, 1),
(3, 'William Crawford', '', 2, '2003-04-19', 'Male', NULL, NULL, NULL, NULL, 1),
(4, 'Renee Crowe', '', 3, '2004-01-15', 'Male', NULL, NULL, NULL, NULL, 1),
(5, 'Lillian Williams', '', 4, '2003-12-14', 'Male', NULL, NULL, NULL, NULL, 1),
(6, 'Betty Mayer', 'new', 5, '2003-07-12', 'Male', NULL, NULL, 9740932644, NULL, 1),
(7, 'Sally Luna', '', 1, '2003-12-19', 'Male', NULL, NULL, NULL, NULL, 2),
(8, 'Richard Smith', '', 2, '2002-12-19', 'Male', NULL, NULL, NULL, NULL, 2),
(9, 'Phyllis Shoop', '', 3, '2003-04-01', 'Male', NULL, NULL, NULL, NULL, 2),
(10, 'Earl Perry', '', 4, '2003-08-15', 'Male', NULL, NULL, NULL, NULL, 2),
(11, 'Minnie Morris', '', 5, '2003-06-18', 'Male', NULL, NULL, NULL, NULL, 2),
(12, 'Lisa Ochoa', '', 1, '2002-05-01', 'Male', NULL, NULL, NULL, NULL, 3),
(13, 'Marcus Holmes', '', 2, '2002-04-12', 'Male', NULL, NULL, NULL, NULL, 3),
(14, 'Eshwar', 'karatagi', 3, '2002-10-12', 'Male', 'venkatesh', 'lalitha', 8987555473, 2147483647, 3),
(15, 'Lavanya', 'gokak', 4, '2002-02-27', 'Female', 'ananth', 'janaki', 9887675643, 2147483647, 3),
(16, 'harshith', 'sindhanur', 5, '2002-06-12', 'Male', 'raju', 'bhavani', 8776594536, 2147483647, 3),
(17, 'Lashwik', 'bangalore', 1, '2002-08-17', 'Male', 'gopal', 'gayathri', 7886594678, 2147483647, 4),
(18, 'sathya', 'davangere', 2, '2002-09-18', 'Female', 'surendher', 'bhanu', 7658458772, 2147483647, 4),
(19, 'Madhu', 'chennagiri', 3, '2002-07-15', 'Male', 'sudheer', 'shasikala', 6777584356, 2147483647, 4),
(20, 'Chaitra', 'honnavar', 4, '2002-01-14', 'Female', 'keshava', 'deepa', 8677543290, 2147483647, 4),
(21, 'Rajith', 'gangavathi', 5, '2002-12-05', 'Male', 'sathyam', 'srilakshmi', 9087543120, 2147483647, 4),
(22, 'arun', 'sindhanur', 1, '2003-11-02', 'Male', 'krishna', 'radha', 9123456342, 2147483647, 5),
(24, 'Anusha', 'Karatagi, Durga Camp K', 8, '1998-11-19', 'Female', 'Srinu', 'Lakshmi', 7996388627, 343723763622, 1),
(25, 'Manu', 'asdfghjkl', 11, '1997-03-21', 'Female', 'Sri', 'Varam', 1234567, 123456, 2);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_subject`
--

CREATE TABLE `tbl_subject` (
  `subject_id` int(25) NOT NULL,
  `subject_code` varchar(25) NOT NULL,
  `subject_name` varchar(25) NOT NULL,
  `subject_grade_id` int(25) NOT NULL,
  `subject_desc` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_subject`
--

INSERT INTO `tbl_subject` (`subject_id`, `subject_code`, `subject_name`, `subject_grade_id`, `subject_desc`) VALUES
(3, '15', 'kannada', 3, 'Language'),
(8, '12', 'English', 1, 'Languagek,fkjb\r\n'),
(9, '14', 'Maths', 2, 'Mathematics');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_teacher`
--

CREATE TABLE `tbl_teacher` (
  `teacher_id` int(11) NOT NULL,
  `teacher_name` varchar(150) NOT NULL,
  `teacher_address` text NOT NULL,
  `teacher_emailid` varchar(100) NOT NULL,
  `teacher_phone_number` bigint(20) DEFAULT NULL,
  `teacher_password` varchar(100) NOT NULL,
  `teacher_qualification` varchar(100) NOT NULL,
  `teacher_doj` date NOT NULL,
  `teacher_image` varchar(100) NOT NULL,
  `teacher_grade_id` int(11) NOT NULL,
  `teacher_designation` varchar(25) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_teacher`
--

INSERT INTO `tbl_teacher` (`teacher_id`, `teacher_name`, `teacher_address`, `teacher_emailid`, `teacher_phone_number`, `teacher_password`, `teacher_qualification`, `teacher_doj`, `teacher_image`, `teacher_grade_id`, `teacher_designation`) VALUES
(2, 'Jonathan Gonzalez', '1810 Kuhl Avenue Gainesville, GA 30501', 'jonathan12@gmail.com', NULL, '$2y$10$s2MmR/Ml6ohRRrrFY0SRQ.vWohGvthVsKe59zgLOIvm3Qd0PzavD2', 'B.Sc, B.Ed', '2019-05-01', '5cdd2ed638edc.jpg', 1, NULL),
(3, 'Peter Parker', '620 Jody Road, Philadelphia, PA 19108', 'peter_parker@gmail.com', NULL, '$2y$10$jmgJN1xvteg6XqBnHvT7UerviGNJOSnF8KFzBHnCky0FJWa74Nvmu', 'M.Sc, B. Ed', '2017-12-31', '5ce53488d50ec.jpg', 2, NULL),
(4, 'John Smith', '780 University Drive, Chicago, IL 60606', 'john.smith@gmail.com', NULL, '$2y$10$Vb9t4CvkJwm41KXgPehuLOFcM7o5Qdm1RFxSBxzh9cvBcc21AUAiW', 'B.Sc', '2019-05-01', '5cdd2f35be8fa.jpg', 3, NULL),
(5, 'Donna Hubber', '3354 Round Table Drive, Cincinnati, OH 45240', 'donna.huber@gmail.com', 1, '$2y$10$SVxX4/7lf3pDs1vrpuJexOG7Ue1e1jqIntGmXip3JzxkB753uxBiO', 'M.Sc', '2019-05-01', '5cdd2f767568c.jpg', 4, NULL),
(7, 'Manu', 'Karatagi', 'manu@gmail.com', 9880876303, '$2y$10$siJ0NqANo1k90cnc0EQzG.M3dh8lttaK/6ngm.k3I3nzXu4y3H8Pa', 'B-Tech', '2021-01-14', '609f87aa51f5c.png', 4, NULL),
(8, 'Ramya', 'Karatagi', 'ramya@gmail.com', NULL, '$2y$10$7tz4dMndYa9xAHRSgpF1KuqW7nZS19Vb6QEDX8RlylaZ6/B.7efwq', 'B-Tech', '2020-08-11', '60a5036de6b9b.jpg', 1, NULL);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tbl_admin`
--
ALTER TABLE `tbl_admin`
  ADD PRIMARY KEY (`admin_id`);

--
-- Indexes for table `tbl_attendance`
--
ALTER TABLE `tbl_attendance`
  ADD PRIMARY KEY (`attendance_id`);

--
-- Indexes for table `tbl_fee_transactions`
--
ALTER TABLE `tbl_fee_transactions`
  ADD PRIMARY KEY (`trans_id`);

--
-- Indexes for table `tbl_grade`
--
ALTER TABLE `tbl_grade`
  ADD PRIMARY KEY (`grade_id`);

--
-- Indexes for table `tbl_grade_fee_structure`
--
ALTER TABLE `tbl_grade_fee_structure`
  ADD PRIMARY KEY (`fee_grade_id`);

--
-- Indexes for table `tbl_student`
--
ALTER TABLE `tbl_student`
  ADD PRIMARY KEY (`student_id`);

--
-- Indexes for table `tbl_subject`
--
ALTER TABLE `tbl_subject`
  ADD PRIMARY KEY (`subject_id`);

--
-- Indexes for table `tbl_teacher`
--
ALTER TABLE `tbl_teacher`
  ADD PRIMARY KEY (`teacher_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tbl_admin`
--
ALTER TABLE `tbl_admin`
  MODIFY `admin_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `tbl_attendance`
--
ALTER TABLE `tbl_attendance`
  MODIFY `attendance_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=31;

--
-- AUTO_INCREMENT for table `tbl_fee_transactions`
--
ALTER TABLE `tbl_fee_transactions`
  MODIFY `trans_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;

--
-- AUTO_INCREMENT for table `tbl_grade`
--
ALTER TABLE `tbl_grade`
  MODIFY `grade_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `tbl_student`
--
ALTER TABLE `tbl_student`
  MODIFY `student_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=29;

--
-- AUTO_INCREMENT for table `tbl_subject`
--
ALTER TABLE `tbl_subject`
  MODIFY `subject_id` int(25) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `tbl_teacher`
--
ALTER TABLE `tbl_teacher`
  MODIFY `teacher_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
