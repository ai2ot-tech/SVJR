<?php

//attendance.php

include('header.php');
echo $_SESSION["teacher_id"];
$grade_id = get_teacher_grade_id($connect, $_SESSION["teacher_id"]);
echo $grade_id;
?>